"use client";
import AdminPage from "@/src/screens/AdminPage";
export default function AdminStudentsPage() {
  return <AdminPage />;
}
