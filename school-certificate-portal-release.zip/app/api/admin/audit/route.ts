import { NextRequest, NextResponse } from "next/server";
import { db } from "@/src/lib/firebase-admin";
import { requireRoles, apiError } from "@/src/lib/security";
import { auditFilterSchema } from "@/src/lib/validation";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(request: NextRequest) {
  try {
    await requireRoles(request, ["approver"]);
    const filters = auditFilterSchema.safeParse({
      start: request.nextUrl.searchParams.get("start") ?? undefined,
      end: request.nextUrl.searchParams.get("end") ?? undefined,
      action: request.nextUrl.searchParams.get("action") ?? undefined,
    });
    if (!filters.success)
      return NextResponse.json(
        { error: "Invalid audit filters." },
        { status: 400 },
      );
    const { start, end, action } = filters.data;
    const exporting = request.nextUrl.searchParams.get("format") === "csv";
    let query = db
      .collection("auditLogs")
      .orderBy("timestamp", "desc")
      .limit(exporting ? 5000 : 300);
    if (start) query = query.where("timestamp", ">=", new Date(start));
    if (end) query = query.where("timestamp", "<=", new Date(end));
    if (action) query = query.where("action", "==", action);
    const snap = await query.get();
    const logs = snap.docs.map((d) => ({
      id: d.id,
      ...d.data(),
      timestamp: d.get("timestamp")?.toDate?.().toISOString?.() ?? null,
    }));
    if (exporting) {
      const lines = [
        "timestamp,actorUid,action,targetId,ipHash",
        ...logs.map((x) =>
          [x.timestamp, x.actorUid, x.action, x.targetId, x.ipHash]
            .map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`)
            .join(","),
        ),
      ];
      return new NextResponse(lines.join("\n"), {
        headers: {
          "Content-Type": "text/csv",
          "Content-Disposition": "attachment; filename=audit-logs.csv",
          "Cache-Control": "no-store",
        },
      });
    }
    return NextResponse.json(
      { logs },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    return apiError(e);
  }
}
